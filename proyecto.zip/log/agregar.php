<!DOCTYPE html>
<html>
<head>
	<title>Agregar</title>
</head>
<body>
	<form method="POST" action="agre.php" >
		<table>
			<tr>
				<td>
					Nombre completo:
				</td>
				<td>
					<input type="name" name="realname">

				</td>

			</tr>
			<tr>
				<td>
					Nombre de usuario:
				</td>
				<td>
					<input type="name" name="nick">

				</td>

			</tr>
			<tr>
				<td>
					Contraseña:
				</td>
				<td>
					<input type="password" name="pass">

				</td>

			</tr>

			<tr>
				<td>
					 Confirmar Contraseña:
				</td>
				<td>
					<input type="password" name="rpass">

				</td>

			</tr>



		</table>
		<input type="submit" name="submit"  value="registrarme" /> <input type="reset" />

</body>
</html>
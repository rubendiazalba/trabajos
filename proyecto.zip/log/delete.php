<!DOCTYPE html>
<html>
<head>
	<title>Borrar</title>
</head>
<body>
	<form method="POST"  action="dele.php" >


	<input type="number" name= "id">
	<input type="submit" name="borra " value= "Borrar"/>
	</form>

	

</body>
</html>
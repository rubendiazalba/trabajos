<!DOCTYPE html>
<html>
<head>
	<title> INICIAR SESION </title>
</head>
<body>
	<h1> INICIAR SESION </h1>
	<form method="POST" action= "logi.php" />
	<table>
		<tr>
			<td>
				NOMBRE DE USUARIO
			</td>
			<td>
				<input type="name" name="nick">

			</td>

		</tr>
		<tr>
			<td>
				CONTRASEÑA
			</td>
			<td>
				<input type="password" name="pass">

			</td>

		</tr>



	</table>
	<input type="submit" name="submit">


	
</form>	

	<?php 
		if (isset ($_POST['submit'])){
			require("registro.php");

	}

	?>

	

</body>
</html>
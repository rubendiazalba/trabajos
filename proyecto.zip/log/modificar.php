<!DOCTYPE html>
<html>
<head>
	<title>modificar</title>
</head>
<body>
	<form method="POST" action="modi.php" />
		<table>
			<tr>
				<td>
				ID:
			</td>
			<td>
				 <input type="number" name="id">

			</td>
			</tr>
			<tr>

				<td>
					Nombre completo:
				</td>
				<td>
					<input type="name" name="realname">

				</td>

			</tr>
			<tr>
				<td>
					Nombre de usuario:
				</td>
				<td>
					<input type="name" name="nick">

				</td>

			</tr>
			<tr>
				<td>
					Contraseña:
				</td>
				<td>
					<input type="password" name="pass">

				</td>

			</tr>

			


		</table>
			<input type="submit" name="submit"  value="registrarme" /> <input type="reset" />

	</form>


</body>
</html>
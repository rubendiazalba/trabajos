<?php
	session_start();
	error_reporting(0);
	
	$se = $_SESSION['nick'];
		if($se == null || $se = ''){
				echo 'no hay autorizacion';
			die();

		}
	?>

<!DOCTYPE html>
<html>
<head>
	<title>EasyCars</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
	<link rel="stylesheet" type="text/css" href="css/fontello.css">	
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<center><a href="cerrar_sesion.php">Salir</a></center>
</head>
<body>
	<header>

		<div class="contenedor">
			<h1 class="icon-cab">EasyCars</h1>
		</div>

	</header>

	<table>
		<form method="POST" action="">

			<a href="delete.php">Borrar</a><br>
			<a href="modificar.php">modificar</a><br>
			<a href="agregar.php">agregar</a><br>
			<a href="registros.php">Registros</a><br>


	

		</form>
		<form method="post" action="csv.php">
				<input type="submit"  value="Exportar CSV" name="export">
			</form>

	</table>

	

</body>
</html>
<?php 
	$realname = $_POST['realname'];
	$nick = $_POST['nick'];
	$pass = $_POST['pass'];
	$rpass = $_POST['rpass'];
	$reqlen = strlen($nick) * strlen($pass) * strlen($rpass);

	if ($reqlen > 0){
		if($pass === $rpass){
			require("connect_db.php");
			//$pass = md5($pass);
			
			$insert="INSERT INTO usuarios(realname,nick,pass) VALUES('".$realname."','".$nick."','".$pass."')";
			
			$r=$conn->query($insert);
			echo 'te has registrado exitosamente';


		}else{

			echo 'las contraseñas no coinciden';
		}


	}else{

		echo "no has completado el registro";
	}


?>
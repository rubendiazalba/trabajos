<?php
	include('connect_db.php');
	if(isset($_POST['export']))
	{
		date_default_timezone_set("America/Mexico_City");
	    $filename = "Usurarios".date('Y-m-d-h-i-sa').".csv";
			////////////////////////////////////////////////////////////////////////////////////////////////
		$f=fopen('php://output','w');

		$fields=array('id','realname','nick');
		
		fputcsv($f,$fields);

		$selTab="SELECT id,realname,nick FROM registrou.usuarios";
		$r=$conn->query($selTab);

	    while($row = mysqli_fetch_assoc($r)) 
	    {
	        fputcsv($f,$row);
	    }
		//Descarga el archivo desde el navegador
		header('Expires: 0');
		header('Cache-control: private');
		header('Content-Type: application/x-octet-stream'); // Archivo de Excel
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Content-Description: File Transfer');
		header('Last-Modified: '.date('D, d M Y H:i:s'));
		header('Content-Disposition: attachment; filename="'.$filename.'"');
		header("Content-Transfer-Encoding: binary");
		fclose($f);	
        //header ("Location: ../vistas/menu.php");   

	}
	$conn->close();
?>
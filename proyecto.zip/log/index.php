<!DOCTYPE html>
<html>
<head>
	<title> Registro</title>
</head>
<body>
	<h1> Registro de Usuarios </h1>
	<form method="POST" action="" />
		<table>
			<tr>
				<td>
					Nombre completo:
				</td>
				<td>
					<input type="name" name="realname">

				</td>

			</tr>
			<tr>
				<td>
					Nombre de usuario:
				</td>
				<td>
					<input type="name" name="nick">

				</td>

			</tr>
			<tr>
				<td>
					Contraseña:
				</td>
				<td>
					<input type="password" name="pass">

				</td>

			</tr>

			<tr>
				<td>
					 Confirmar Contraseña:
				</td>
				<td>
					<input type="password" name="rpass">

				</td>

			</tr>



		</table>
		<input type="submit" name="submit"  value="registrarme" /> <input type="reset" />

	</form>
	<?php 
		if (isset ($_POST['submit'])){
			require("registro.php");

	}

	?>
</body>
</html>






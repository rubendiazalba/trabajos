<?php 

	include('connect_db.php');

 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Registros</title>
	
</head>
<body>

<br>
	<div class="Registros">
		<div class="Usuarios">
		</div>
		<table border="1" >
			<tr>
				<td>id</td>
				<td>realname</td>
				<td>nick</td>
					
			</tr>

			<?php 
			$sql="SELECT * from usuarios";
			$result=mysqli_query($conn,$sql);

			while($mostrar=mysqli_fetch_array($result)){
			 ?>
			 	<tr>
					<td><?php echo $mostrar['id'] ?></td>
					<td><?php echo $mostrar['realname'] ?></td>
					<td><?php echo $mostrar['nick'] ?></td>
					
				</tr>
		<?php 
		}
		 ?>
		</table>
		<p class="form-link"><a href="..indexm.php">Regresar</a></p>	
	</div>

</body>
</html>
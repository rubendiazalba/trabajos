<?php 
session_start();

	
	


	$nick = $_POST['nick'] ;
	$_SESSION['nick'] = $nick;
	$pass = $_POST['pass'];
	
	

	$query = "SELECT * FROM usuarios WHERE nick = '".$nick."' AND pass = '".$pass."'";

include ("connect_db.php");

	$res = mysqli_query($conn,$query);
	$da = mysqli_num_rows($res);


	if($da > 0){

		
		header("location: indexm.php");

	}else{

		
			header("location: index.php");
	}
		mysqli_result($da);
		mysql_close($conn);

		